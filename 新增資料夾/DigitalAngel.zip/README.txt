Please download the whole folder and save it at a place on your computer where you remember.
Next, open your chrome browser and type chrome://extensions in the address bar.
You will see a checkbox named ��Developer mode�� in the top right-hand corner, check it if it��s unckecked.
Finally, click ��Load unpacked extension...�� and direct to where you have saved the folder.
Now you should see a cute angel-wings icon in the top right-hand corner of your browser, go and try for it!
(See https://developer.chrome.com/extensions/getstarted#unpacked for more help.)